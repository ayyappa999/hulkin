export const environment = {
    production: false,

    region: 'us-east-2',

    identityPoolId: 'us-east-2:e4f6f9ce-d594-4a98-a6e0-98b588b27d67',
    userPoolId: 'us-east-2_MoFwUdGAf',
    clientId: '3n0nla95r4e7f5nduo9du7it9l',

    rekognitionBucket: 'rekognition-pics',
    albumName: "usercontent",
    bucketRegion: 'ap-northeast-1',

    ddbTableName: 'LoginTrails3'
};

